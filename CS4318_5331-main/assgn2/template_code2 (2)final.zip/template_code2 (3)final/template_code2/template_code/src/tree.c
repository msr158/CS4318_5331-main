#include<tree.h>
#include<strtab.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>

 /* string values for ast node types, makes tree output more readable */
char *charnodeNames[8] = {"program", "vardecl", "typeSpecfier", "assignStmt", "ifStmt", "exp", "integer", "identifier"};


tree *ast; 

tree *maketree(int kind) {
  tree *this = (tree *) malloc(sizeof(struct treenode));
  this->nodeKind = kind;
  this->numChildren = 0;
  return this;

}

tree *maketreeWithVal(int kind, int val) {
  tree *this = (tree *) malloc(sizeof(struct treenode));
  this->nodeKind = kind;
  this->numChildren = 0;
  this->val = val;
  return this;

}

void addChild(tree *parent, tree *child) {
  if (parent->numChildren == MAXCHILDREN) {
    printf("Cannot add child to parent node\n");
    exit(1);
  }
  /*nextAvailChild(parent) = child;*/
  parent->children[parent->numChildren] = child;
  child->parent = parent;
  parent->numChildren++;
}

void printAst(tree *node, int nestLevel) {

  //printf("%s\n", charnodeNames[node->nodeKind]);
  if (node->val != 0) {
        printf("%s (%s)\n", charnodeNames[node->nodeKind], node->val);
    } else {
        printf("%s\n", charnodeNames[node->nodeKind]);
    }

  int i, j;

  for (i = 0; i < node->numChildren; i++)  {
    for (j = 0; j < nestLevel; j++) 
      printf("\t");
    printAst(node->children[i], nestLevel + 1);
  }


}
